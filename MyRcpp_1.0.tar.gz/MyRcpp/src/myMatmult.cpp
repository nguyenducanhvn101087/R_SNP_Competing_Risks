#include <RcppEigen.h>
#include "myMatmult.h"

// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::export]]
Eigen::MatrixXd myMatmult(const Eigen::MatrixXd& A, const Eigen::MatrixXd& B) {
  return A*B;
}
