Eigen::MatrixXd myMatmult(const Eigen::MatrixXd& A, const Eigen::MatrixXd& B);
