#include <Rcpp.h>
#include <RcppEigen.h>
#include <Eigen/Dense>
#include <Eigen/Cholesky>
#include "mychol.h"

// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::export]]
Rcpp::List mychol(const Eigen::MatrixXd& A) {
  Eigen::LLT<Eigen::MatrixXd> lltOfA(A);
  Eigen::MatrixXd L = lltOfA.matrixL();
  int p = A.cols();
  Eigen::MatrixXd b = Eigen::MatrixXd::Identity(p, p);
  b = lltOfA.solve(b);
  return Rcpp::List::create(Rcpp::Named("L") = L, Rcpp::Named("Inv") = b);
}
