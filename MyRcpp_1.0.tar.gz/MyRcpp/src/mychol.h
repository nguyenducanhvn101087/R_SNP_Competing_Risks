Rcpp::List mychol(const Eigen::MatrixXd& A);
